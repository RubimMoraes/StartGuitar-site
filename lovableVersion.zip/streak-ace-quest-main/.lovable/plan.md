# Plano: StartGuitar — Página única com navegação horizontal

## Visão geral
Refazer `src/routes/index.tsx` como uma **única página** (`/`) que contém as 3 áreas do site, alinhadas conceitualmente como no sitemap:

```text
[ Treino ]  ←  [ Página Inicial ]  →  [ Teoria musical ]
```

A navegação entre as 3 áreas acontece por **duas setas circulares flutuantes** (esquerda e direita) que ficam fixas na lateral da viewport e acompanham o scroll. Tudo vive em uma rota só (`/`), usando âncoras internas (`#inicio`, `#treino`, `#teoria`) — sem rotas separadas, conforme pedido.

O template de habit tracker (DailyMint) será **substituído** nessa rota. A app `/app`, `/login`, etc. permanecem intactas por enquanto (não vamos quebrar nada do backend), mas o foco visual passa a ser StartGuitar.

## Identidade visual
- **Nome**: StartGuitar
- **Idioma**: Português (BR)
- **Paleta**: manter base escura/âmbar atual (#FDAA3E sobre fundo escuro `#0f0d0b`) — combina com o universo "madeira/violão" e com o wireframe escuro enviado.
- **Tipografia**: Plus Jakarta Sans (já no projeto).
- **Ícone**: trocar `Infinity` por `Guitar` (lucide-react) em todo header/footer.

## Estrutura da página (`src/routes/index.tsx`)

### 1. Header / Hero (`#inicio`)
- Navbar fixa no topo com logo "StartGuitar" + 3 links âncora: **Início · Treino · Teoria**.
- Hero com imagem de fundo (violão / mãos tocando) à direita, gradiente escuro à esquerda.
- Título: "Aprenda violão do zero, no seu ritmo."
- Subtítulo curto sobre guiar iniciantes até tocar suas primeiras músicas.
- CTA âmbar "Começar agora" → âncora `#temas`.

### 2. Abas de temas introdutórios (logo abaixo do hero, ainda em `#inicio`)
- Componente `Tabs` (shadcn) com 4–5 abas alternando conteúdo curto:
  - "O que é música"
  - "Partes do violão"
  - "Como segurar e postura"
  - "Afinação básica"
  - "Primeiros passos"
- Cada aba: texto + ilustração/ícone. Conteúdo inicial em texto estático (placeholder editorial pronto para produção).

### 3. Seção Treino (`#treino`) — "página da esquerda"
- Header da seção com 3 abas (`Tabs` shadcn):
  1. **Biblioteca de acordes** — grid de cards de acordes (C, G, D, Em, Am, F…) cada um com diagrama SVG simples do braço do violão (6 cordas × 4 casas, bolinhas nas posições). Componente `<ChordDiagram />` reutilizável.
  2. **Treino de ouvido** — card com player simulado: botão "Tocar nota" + 4 opções de resposta (C/D/E/G). Lógica simples com `Audio` HTML usando WebAudio API (oscillator) para gerar tons — sem dependências externas.
  3. **Metrônomo** — controle de BPM (slider 40–200), play/pause, indicador visual pulsante. WebAudio API para o "tick".

### 4. Seção Teoria musical (`#teoria`) — "página da direita"
- Layout de 2 colunas (desktop): conteúdo à esquerda + **menu de assuntos** vertical fixo à direita (sticky).
- Menu lateral com 3 grupos (collapsible):
  - **Como funciona o violão** (anatomia, cordas, afinação)
  - **Harmonia** (intervalos, escalas, tonalidade)
  - **Formação de acordes** (tríades, cifras, inversões)
- Clicar num item rola suavemente para o subtítulo correspondente dentro do conteúdo.
- Conteúdo: artigos curtos em texto estático (placeholders editoriais bem escritos).

### 5. Setas flutuantes de navegação
- 2 botões circulares (`w-12 h-12 rounded-full`) `position: fixed`, centralizados verticalmente (`top: 50%`), um à esquerda, outro à direita.
- Esquerda: ícone `ChevronLeft` → rola para `#treino` (ou `#inicio` se já estiver em treino).
- Direita: ícone `ChevronRight` → rola para `#teoria` (ou `#inicio` se já estiver em teoria).
- Lógica com `IntersectionObserver` para saber qual seção está visível e atualizar o destino + ocultar a seta no extremo (ex: na seção Treino, esconde a seta esquerda).
- Visual: fundo escuro semi-transparente com borda âmbar, hover suave, escala leve no clique. Mobile: ainda visíveis, um pouco menores.

### 6. Footer
- Logo + créditos + links âncora.

## Arquivos afetados
- **`src/routes/index.tsx`** — reescrito por completo (substitui landing DailyMint).
- **`src/components/guitar/ChordDiagram.tsx`** — novo, SVG dos acordes.
- **`src/components/guitar/EarTrainer.tsx`** — novo, treino de ouvido com WebAudio.
- **`src/components/guitar/Metronome.tsx`** — novo, metrônomo com WebAudio.
- **`src/components/guitar/FloatingNav.tsx`** — novo, setas flutuantes com IntersectionObserver.
- **`src/components/guitar/TheorySidebar.tsx`** — novo, menu lateral de assuntos.
- **Asset hero**: gerar imagem de violão em `src/assets/startguitar-hero.jpg` (via geração de imagem) ou reaproveitar o `hero-bg.jpg` atual temporariamente.
- **Não tocar** em `src/routes/app.tsx`, `login.tsx`, `settings.tsx`, etc.

## Detalhes técnicos
- Continua TanStack Start; rota `/` continua sendo `createFileRoute("/")`.
- Scroll suave: CSS `scroll-behavior: smooth` no `html` (já está) + `scroll-margin-top` nas seções para compensar navbar.
- WebAudio: criado sob demanda (no primeiro clique) para evitar warning de autoplay.
- SSR-safe: hooks de áudio e IntersectionObserver dentro de `useEffect`.
- Sem novas dependências npm.

## Fora desta fase
- Backend, autenticação ou persistência das ferramentas de treino.
- Conteúdo editorial completo (entra texto inicial decente, refinamos depois).
- Áudio com samples reais de violão (usamos osciladores sintéticos por ora).
- Páginas separadas `/treino`, `/teoria`, `/musicas` — tudo vive na index conforme você pediu.

---

Aprovando o plano, eu já implemento a index completa, os 5 componentes novos e troco o branding para StartGuitar.
