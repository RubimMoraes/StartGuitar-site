import { useEffect, useState } from "react";

export type TheoryTopic = {
  id: string;
  group: string;
  title: string;
};

export const THEORY_TOPICS: TheoryTopic[] = [
  { id: "violao-anatomia", group: "Como funciona o violão", title: "Anatomia do violão" },
  { id: "violao-cordas", group: "Como funciona o violão", title: "As cordas e a afinação" },
  { id: "violao-som", group: "Como funciona o violão", title: "Como o som é produzido" },
  { id: "harmonia-intervalos", group: "Harmonia", title: "Intervalos musicais" },
  { id: "harmonia-escalas", group: "Harmonia", title: "Escalas maiores e menores" },
  { id: "harmonia-tonalidade", group: "Harmonia", title: "Tonalidade e campo harmônico" },
  { id: "acordes-triades", group: "Formação de acordes", title: "Tríades" },
  { id: "acordes-cifras", group: "Formação de acordes", title: "Lendo cifras" },
  { id: "acordes-inversoes", group: "Formação de acordes", title: "Inversões" },
];

export function TheorySidebar() {
  const [active, setActive] = useState<string>(THEORY_TOPICS[0].id);

  useEffect(() => {
    const els = THEORY_TOPICS.map((t) => document.getElementById(t.id)).filter(Boolean) as HTMLElement[];
    if (!els.length) return;
    const obs = new IntersectionObserver(
      (entries) => {
        const v = entries.filter((e) => e.isIntersecting).sort((a, b) => b.intersectionRatio - a.intersectionRatio);
        if (v[0]) setActive(v[0].target.id);
      },
      { rootMargin: "-30% 0px -50% 0px", threshold: [0, 0.5, 1] }
    );
    els.forEach((e) => obs.observe(e));
    return () => obs.disconnect();
  }, []);

  const groups = Array.from(new Set(THEORY_TOPICS.map((t) => t.group)));

  return (
    <nav className="space-y-6 text-sm">
      {groups.map((g) => (
        <div key={g}>
          <h4 className="text-xs font-semibold uppercase tracking-widest text-primary mb-3">{g}</h4>
          <ul className="space-y-1.5 border-l border-border pl-4">
            {THEORY_TOPICS.filter((t) => t.group === g).map((t) => (
              <li key={t.id}>
                <a
                  href={`#${t.id}`}
                  className={`block py-1 transition-colors ${
                    active === t.id
                      ? "text-primary font-medium"
                      : "text-muted-foreground hover:text-foreground"
                  }`}
                >
                  {t.title}
                </a>
              </li>
            ))}
          </ul>
        </div>
      ))}
    </nav>
  );
}