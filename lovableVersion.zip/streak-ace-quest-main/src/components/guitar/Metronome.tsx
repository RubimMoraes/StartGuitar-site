import { useEffect, useRef, useState } from "react";
import { Play, Pause, Minus, Plus } from "lucide-react";

export function Metronome() {
  const [bpm, setBpm] = useState(90);
  const [playing, setPlaying] = useState(false);
  const [beat, setBeat] = useState(0);
  const ctxRef = useRef<AudioContext | null>(null);
  const timerRef = useRef<number | null>(null);
  const beatRef = useRef(0);

  const tick = (accent: boolean) => {
    if (!ctxRef.current) return;
    const ctx = ctxRef.current;
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.frequency.value = accent ? 1500 : 900;
    gain.gain.setValueAtTime(0.001, ctx.currentTime);
    gain.gain.exponentialRampToValueAtTime(0.6, ctx.currentTime + 0.005);
    gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.08);
    osc.connect(gain).connect(ctx.destination);
    osc.start();
    osc.stop(ctx.currentTime + 0.1);
  };

  useEffect(() => {
    if (!playing) {
      if (timerRef.current) window.clearInterval(timerRef.current);
      return;
    }
    if (!ctxRef.current) ctxRef.current = new (window.AudioContext || (window as any).webkitAudioContext)();
    const interval = 60000 / bpm;
    beatRef.current = 0;
    tick(true);
    setBeat(0);
    timerRef.current = window.setInterval(() => {
      beatRef.current = (beatRef.current + 1) % 4;
      setBeat(beatRef.current);
      tick(beatRef.current === 0);
    }, interval);
    return () => {
      if (timerRef.current) window.clearInterval(timerRef.current);
    };
  }, [playing, bpm]);

  return (
    <div className="rounded-2xl border border-border bg-card p-6 max-w-md mx-auto text-card-foreground">
      <div className="text-center mb-6">
        <h3 className="font-semibold text-lg">Metrônomo</h3>
        <p className="text-xs text-muted-foreground">Treine seu tempo e ritmo</p>
      </div>

      <div className="flex items-center justify-center gap-4 mb-6">
        <button
          onClick={() => setBpm((b) => Math.max(40, b - 5))}
          className="w-10 h-10 rounded-full border border-border hover:bg-muted flex items-center justify-center"
        >
          <Minus className="w-4 h-4" />
        </button>
        <div className="text-center min-w-[120px]">
          <div className="text-5xl font-bold tabular-nums">{bpm}</div>
          <div className="text-xs text-muted-foreground mt-1">BPM</div>
        </div>
        <button
          onClick={() => setBpm((b) => Math.min(200, b + 5))}
          className="w-10 h-10 rounded-full border border-border hover:bg-muted flex items-center justify-center"
        >
          <Plus className="w-4 h-4" />
        </button>
      </div>

      <input
        type="range"
        min={40}
        max={200}
        value={bpm}
        onChange={(e) => setBpm(Number(e.target.value))}
        className="w-full accent-primary mb-6"
      />

      <div className="flex justify-center gap-2 mb-6">
        {[0, 1, 2, 3].map((i) => (
          <div
            key={i}
            className={`w-3 h-3 rounded-full transition-all ${
              playing && beat === i
                ? i === 0
                  ? "bg-primary scale-150"
                  : "bg-foreground scale-125"
                : "bg-border"
            }`}
          />
        ))}
      </div>

      <button
        onClick={() => setPlaying((p) => !p)}
        className="w-full inline-flex items-center justify-center gap-2 rounded-xl bg-primary text-primary-foreground py-4 font-semibold hover:opacity-90 transition active:scale-[0.98]"
      >
        {playing ? <Pause className="w-5 h-5" /> : <Play className="w-5 h-5" />}
        {playing ? "Parar" : "Iniciar"}
      </button>
    </div>
  );
}