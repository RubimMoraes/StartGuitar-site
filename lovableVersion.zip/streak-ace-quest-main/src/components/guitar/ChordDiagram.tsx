import React from "react";

export type ChordShape = {
  name: string;
  // 6 strings from low E (string 6) to high e (string 1).
  // value: 0 = open, -1 = muted, 1..n = fret number
  frets: [number, number, number, number, number, number];
  // optional barre: { fret, fromString, toString }
  barre?: { fret: number; from: number; to: number };
};

export function ChordDiagram({ chord, size = 120 }: { chord: ChordShape; size?: number }) {
  const FRETS = 4;
  const STRINGS = 6;
  const w = size;
  const h = size * 1.15;
  const padX = size * 0.14;
  const padTop = size * 0.22;
  const padBottom = size * 0.08;
  const gridW = w - padX * 2;
  const gridH = h - padTop - padBottom;
  const stringGap = gridW / (STRINGS - 1);
  const fretGap = gridH / FRETS;

  return (
    <svg viewBox={`0 0 ${w} ${h}`} width={w} height={h} className="block">
      {/* Chord name */}
      <text
        x={w / 2}
        y={padTop * 0.55}
        textAnchor="middle"
        fontSize={size * 0.18}
        fontWeight={700}
        fill="currentColor"
      >
        {chord.name}
      </text>

      {/* Open / muted markers */}
      {chord.frets.map((f, i) => {
        const stringIndex = STRINGS - 1 - i; // svg left-to-right: string 6..1
        const x = padX + stringIndex * stringGap;
        const y = padTop - 8;
        if (f === 0) {
          return <circle key={i} cx={x} cy={y} r={size * 0.035} fill="none" stroke="currentColor" strokeWidth={1.5} />;
        }
        if (f === -1) {
          return (
            <text key={i} x={x} y={y + 3} textAnchor="middle" fontSize={size * 0.09} fill="currentColor" opacity={0.6}>
              ×
            </text>
          );
        }
        return null;
      })}

      {/* Nut (top thick line) */}
      <line x1={padX} y1={padTop} x2={w - padX} y2={padTop} stroke="currentColor" strokeWidth={3} />

      {/* Frets */}
      {Array.from({ length: FRETS }).map((_, i) => (
        <line
          key={`fret-${i}`}
          x1={padX}
          y1={padTop + (i + 1) * fretGap}
          x2={w - padX}
          y2={padTop + (i + 1) * fretGap}
          stroke="currentColor"
          strokeWidth={1}
          opacity={0.5}
        />
      ))}

      {/* Strings */}
      {Array.from({ length: STRINGS }).map((_, i) => (
        <line
          key={`string-${i}`}
          x1={padX + i * stringGap}
          y1={padTop}
          x2={padX + i * stringGap}
          y2={padTop + gridH}
          stroke="currentColor"
          strokeWidth={1}
          opacity={0.6}
        />
      ))}

      {/* Barre */}
      {chord.barre && (
        <rect
          x={padX + (STRINGS - chord.barre.from) * stringGap - size * 0.05}
          y={padTop + (chord.barre.fret - 0.5) * fretGap - size * 0.05}
          width={(chord.barre.from - chord.barre.to) * stringGap + size * 0.1}
          height={size * 0.1}
          rx={size * 0.05}
          fill="currentColor"
        />
      )}

      {/* Finger dots */}
      {chord.frets.map((f, i) => {
        if (f <= 0) return null;
        const stringIndex = STRINGS - 1 - i;
        const x = padX + stringIndex * stringGap;
        const y = padTop + (f - 0.5) * fretGap;
        return <circle key={`dot-${i}`} cx={x} cy={y} r={size * 0.07} fill="currentColor" />;
      })}
    </svg>
  );
}

export const COMMON_CHORDS: ChordShape[] = [
  { name: "C", frets: [-1, 3, 2, 0, 1, 0] },
  { name: "G", frets: [3, 2, 0, 0, 0, 3] },
  { name: "D", frets: [-1, -1, 0, 2, 3, 2] },
  { name: "A", frets: [-1, 0, 2, 2, 2, 0] },
  { name: "E", frets: [0, 2, 2, 1, 0, 0] },
  { name: "Em", frets: [0, 2, 2, 0, 0, 0] },
  { name: "Am", frets: [-1, 0, 2, 2, 1, 0] },
  { name: "Dm", frets: [-1, -1, 0, 2, 3, 1] },
];