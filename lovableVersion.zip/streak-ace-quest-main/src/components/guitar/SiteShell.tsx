import { Link, useRouterState } from "@tanstack/react-router";
import { Guitar, ChevronLeft, ChevronRight } from "lucide-react";

const ORDER = ["/treino", "/", "/teoria"] as const;
type Path = (typeof ORDER)[number];

const LABELS: Record<Path, string> = {
  "/": "Início",
  "/treino": "Treino",
  "/teoria": "Teoria",
};

function FloatingNav({ current }: { current: Path }) {
  const idx = ORDER.indexOf(current);
  const left = idx > 0 ? ORDER[idx - 1] : null;
  const right = idx < ORDER.length - 1 ? ORDER[idx + 1] : null;

  const base =
    "fixed top-1/2 -translate-y-1/2 z-40 w-12 h-12 sm:w-14 sm:h-14 rounded-full bg-background/70 backdrop-blur-md border border-primary/40 text-primary hover:bg-primary hover:text-primary-foreground transition-all active:scale-95 shadow-lg flex flex-col items-center justify-center gap-0.5";

  return (
    <>
      {left && (
        <Link to={left} aria-label={`Ir para ${LABELS[left]}`} className={`${base} left-3 sm:left-5`}>
          <ChevronLeft className="w-5 h-5" />
          <span className="text-[9px] font-medium leading-none">{LABELS[left]}</span>
        </Link>
      )}
      {right && (
        <Link to={right} aria-label={`Ir para ${LABELS[right]}`} className={`${base} right-3 sm:right-5`}>
          <ChevronRight className="w-5 h-5" />
          <span className="text-[9px] font-medium leading-none">{LABELS[right]}</span>
        </Link>
      )}
    </>
  );
}

function Navbar() {
  return (
    <header className="fixed top-0 inset-x-0 z-50 backdrop-blur-md bg-background/70 border-b border-border/40">
      <nav className="max-w-6xl mx-auto px-5 h-14 flex items-center justify-between">
        <Link to="/" className="flex items-center gap-2">
          <Guitar className="w-5 h-5 text-primary" strokeWidth={2.2} />
          <span className="font-semibold tracking-tight">StartGuitar</span>
        </Link>
        <div className="flex items-center gap-6 text-sm text-muted-foreground">
          <Link to="/treino" className="hover:text-foreground transition" activeProps={{ className: "text-primary font-medium" }}>
            Treino
          </Link>
          <Link to="/" className="hover:text-foreground transition" activeOptions={{ exact: true }} activeProps={{ className: "text-primary font-medium" }}>
            Início
          </Link>
          <Link to="/teoria" className="hover:text-foreground transition" activeProps={{ className: "text-primary font-medium" }}>
            Teoria
          </Link>
        </div>
      </nav>
    </header>
  );
}

function Footer() {
  return (
    <footer className="border-t border-border/40 py-10 bg-background">
      <div className="max-w-6xl mx-auto px-5 flex flex-col sm:flex-row items-center justify-between gap-4">
        <div className="flex items-center gap-2">
          <Guitar className="w-5 h-5 text-primary" strokeWidth={2.2} />
          <span className="font-semibold text-sm">StartGuitar</span>
        </div>
        <div className="flex gap-6 text-sm text-muted-foreground">
          <Link to="/" className="hover:text-foreground transition">Início</Link>
          <Link to="/treino" className="hover:text-foreground transition">Treino</Link>
          <Link to="/teoria" className="hover:text-foreground transition">Teoria</Link>
        </div>
        <p className="text-xs text-muted-foreground">© {new Date().getFullYear()} StartGuitar</p>
      </div>
    </footer>
  );
}

export function SiteShell({ children }: { children: React.ReactNode }) {
  const pathname = useRouterState({ select: (s) => s.location.pathname });
  const current = (ORDER as readonly string[]).includes(pathname) ? (pathname as Path) : "/";
  return (
    <div className="dark min-h-screen bg-background text-foreground">
      <Navbar />
      <FloatingNav current={current} />
      <main>{children}</main>
      <Footer />
    </div>
  );
}