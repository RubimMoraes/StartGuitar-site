import { useRef, useState } from "react";
import { Play, RefreshCw, Check, X } from "lucide-react";

const NOTES: { name: string; freq: number }[] = [
  { name: "Dó (C)", freq: 261.63 },
  { name: "Ré (D)", freq: 293.66 },
  { name: "Mi (E)", freq: 329.63 },
  { name: "Fá (F)", freq: 349.23 },
  { name: "Sol (G)", freq: 392.0 },
  { name: "Lá (A)", freq: 440.0 },
  { name: "Si (B)", freq: 493.88 },
];

function pickRound() {
  const target = NOTES[Math.floor(Math.random() * NOTES.length)];
  const pool = [target];
  while (pool.length < 4) {
    const cand = NOTES[Math.floor(Math.random() * NOTES.length)];
    if (!pool.includes(cand)) pool.push(cand);
  }
  return { target, options: pool.sort(() => Math.random() - 0.5) };
}

export function EarTrainer() {
  const ctxRef = useRef<AudioContext | null>(null);
  const [round, setRound] = useState(() => pickRound());
  const [answer, setAnswer] = useState<string | null>(null);
  const [score, setScore] = useState({ ok: 0, total: 0 });

  const playNote = (freq: number) => {
    if (typeof window === "undefined") return;
    if (!ctxRef.current) ctxRef.current = new (window.AudioContext || (window as any).webkitAudioContext)();
    const ctx = ctxRef.current;
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = "triangle";
    osc.frequency.value = freq;
    gain.gain.setValueAtTime(0, ctx.currentTime);
    gain.gain.linearRampToValueAtTime(0.25, ctx.currentTime + 0.02);
    gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 1.5);
    osc.connect(gain).connect(ctx.destination);
    osc.start();
    osc.stop(ctx.currentTime + 1.5);
  };

  const choose = (name: string) => {
    if (answer) return;
    setAnswer(name);
    const ok = name === round.target.name;
    setScore((s) => ({ ok: s.ok + (ok ? 1 : 0), total: s.total + 1 }));
  };

  const next = () => {
    setAnswer(null);
    setRound(pickRound());
  };

  return (
    <div className="rounded-2xl border border-border bg-card p-6 max-w-md mx-auto text-card-foreground">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h3 className="font-semibold text-lg">Treino de ouvido</h3>
          <p className="text-xs text-muted-foreground">Identifique a nota tocada</p>
        </div>
        <div className="text-sm tabular-nums text-muted-foreground">
          {score.ok}/{score.total}
        </div>
      </div>

      <button
        onClick={() => playNote(round.target.freq)}
        className="w-full inline-flex items-center justify-center gap-2 rounded-xl bg-primary text-primary-foreground py-4 font-semibold hover:opacity-90 transition active:scale-[0.98]"
      >
        <Play className="w-5 h-5" /> Tocar nota
      </button>

      <div className="grid grid-cols-2 gap-2 mt-5">
        {round.options.map((o) => {
          const isCorrect = answer && o.name === round.target.name;
          const isWrong = answer === o.name && o.name !== round.target.name;
          return (
            <button
              key={o.name}
              onClick={() => choose(o.name)}
              className={`rounded-xl border px-4 py-3 text-sm font-medium transition flex items-center justify-between
                ${isCorrect ? "border-primary bg-primary/15 text-primary" : ""}
                ${isWrong ? "border-destructive bg-destructive/10 text-destructive" : ""}
                ${!answer ? "border-border hover:bg-muted" : ""}
              `}
            >
              <span>{o.name}</span>
              {isCorrect && <Check className="w-4 h-4" />}
              {isWrong && <X className="w-4 h-4" />}
            </button>
          );
        })}
      </div>

      {answer && (
        <button
          onClick={next}
          className="w-full mt-5 inline-flex items-center justify-center gap-2 rounded-xl border border-border py-3 text-sm font-medium hover:bg-muted transition"
        >
          <RefreshCw className="w-4 h-4" /> Próxima nota
        </button>
      )}
    </div>
  );
}