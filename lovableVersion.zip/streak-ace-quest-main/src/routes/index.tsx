import { createFileRoute, Link } from "@tanstack/react-router";
import { Music2, Dumbbell, BookOpen, ArrowRight } from "lucide-react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { SiteShell } from "@/components/guitar/SiteShell";
import heroBg from "@/assets/startguitar-hero.jpg";

export const Route = createFileRoute("/")({
  component: LandingPage,
  head: () => ({
    meta: [
      { title: "StartGuitar — Aprenda violão do zero, no seu ritmo" },
      {
        name: "description",
        content:
          "Plataforma para iniciantes no violão: introdução ao instrumento, teoria musical, biblioteca de acordes, treino de ouvido e metrônomo.",
      },
      { property: "og:title", content: "StartGuitar — Aprenda violão do zero" },
      {
        property: "og:description",
        content: "Comece sua jornada no violão com prática estruturada e consistente.",
      },
    ],
  }),
});

const INTRO_TABS = [
  {
    id: "musica",
    label: "O que é música",
    body:
      "Música é a organização de sons no tempo. Combinamos altura (notas), duração (ritmo) e intensidade (dinâmica) para criar algo expressivo. Antes mesmo de tocar, ouvir com atenção já é fazer música.",
  },
  {
    id: "instrumento",
    label: "Partes do violão",
    body:
      "O violão tem três partes principais: o corpo (caixa de ressonância), o braço (onde ficam as casas e os trastes) e a cabeça (onde estão as tarraxas para afinar). Cada uma tem um papel no som final.",
  },
  {
    id: "postura",
    label: "Postura",
    body:
      "Sente com as costas eretas, apoie o violão na perna direita (se for destro) e mantenha o braço do instrumento ligeiramente inclinado para cima. A mão esquerda deve ficar relaxada, com o polegar atrás do braço.",
  },
  {
    id: "afinacao",
    label: "Afinação",
    body:
      "A afinação padrão do violão, da 6ª para a 1ª corda, é: Mi, Lá, Ré, Sol, Si, Mi (E A D G B E). Use um afinador de celular ou um aplicativo para começar — afinar é o primeiro passo de toda prática.",
  },
  {
    id: "primeiros",
    label: "Primeiros passos",
    body:
      "Comece com 2 ou 3 acordes (como Em, C e G). Pratique a troca lenta entre eles antes de tentar tocar uma música inteira. Consistência diária supera longas sessões esporádicas.",
  },
];

function LandingPage() {
  return (
    <SiteShell>
      <section
        className="relative pt-28 pb-20 sm:pt-36 sm:pb-28 overflow-hidden"
        style={{ background: "#0b0907" }}
      >
        <img
          src={heroBg}
          alt=""
          width={1920}
          height={1280}
          className="absolute inset-0 w-full h-full object-cover object-right opacity-80 pointer-events-none select-none"
          aria-hidden="true"
        />
        <div
          className="absolute inset-0 pointer-events-none"
          style={{ background: "linear-gradient(to right, rgba(11,9,7,0.95), rgba(11,9,7,0.5), transparent)" }}
        />
        <div className="relative z-10 max-w-6xl mx-auto px-5">
          <div className="max-w-xl">
            <span className="inline-flex items-center gap-2 rounded-full border border-primary/30 bg-primary/10 text-primary px-3 py-1 text-xs font-medium">
              <Music2 className="w-3.5 h-3.5" /> Para iniciantes no violão
            </span>
            <h1 className="mt-5 text-4xl sm:text-5xl md:text-6xl font-bold tracking-tight" style={{ lineHeight: 1.08 }}>
              Aprenda violão do zero, no seu ritmo.
            </h1>
            <p className="mt-5 text-lg text-foreground/80" style={{ textWrap: "pretty" }}>
              Um caminho claro do primeiro acorde até suas primeiras músicas — com teoria, prática estruturada e
              ferramentas para treinar todo dia.
            </p>
            <div className="mt-8 flex flex-wrap gap-3">
              <a
                href="#temas"
                className="inline-flex items-center gap-2 rounded-xl bg-primary text-primary-foreground px-6 py-3 text-sm font-semibold hover:opacity-90 transition active:scale-[0.97]"
              >
                Começar agora <ArrowRight className="w-4 h-4" />
              </a>
              <Link
                to="/treino"
                className="inline-flex items-center gap-2 rounded-xl border border-border bg-background/40 backdrop-blur px-6 py-3 text-sm font-medium hover:bg-background/60 transition"
              >
                <Dumbbell className="w-4 h-4" /> Ferramentas de treino
              </Link>
            </div>
          </div>
        </div>
      </section>

      <section id="temas" className="py-20 sm:py-24 bg-background scroll-mt-16">
        <div className="max-w-4xl mx-auto px-5">
          <div className="text-center mb-10">
            <p className="text-xs font-semibold uppercase tracking-widest text-primary mb-3">Introdução</p>
            <h2 className="text-3xl sm:text-4xl font-bold tracking-tight">Por onde começar</h2>
            <p className="mt-3 text-muted-foreground max-w-xl mx-auto">
              Conceitos básicos sobre música e o instrumento para você começar com o pé direito.
            </p>
          </div>

          <Tabs defaultValue={INTRO_TABS[0].id} className="w-full">
            <TabsList className="flex flex-wrap h-auto bg-muted/50 p-1 rounded-xl">
              {INTRO_TABS.map((t) => (
                <TabsTrigger key={t.id} value={t.id} className="flex-1 min-w-[120px]">
                  {t.label}
                </TabsTrigger>
              ))}
            </TabsList>
            {INTRO_TABS.map((t) => (
              <TabsContent key={t.id} value={t.id} className="mt-6">
                <div className="rounded-2xl border border-border bg-card p-6 sm:p-8">
                  <p className="text-base leading-relaxed text-card-foreground">{t.body}</p>
                </div>
              </TabsContent>
            ))}
          </Tabs>

          <div className="mt-12 grid sm:grid-cols-2 gap-4">
            <Link
              to="/treino"
              className="group rounded-2xl border border-border bg-card p-6 hover:border-primary/50 transition flex items-start gap-4"
            >
              <div className="w-10 h-10 rounded-xl bg-primary/15 text-primary flex items-center justify-center flex-shrink-0">
                <Dumbbell className="w-5 h-5" />
              </div>
              <div>
                <h3 className="font-semibold mb-1 group-hover:text-primary transition">Treino</h3>
                <p className="text-sm text-muted-foreground">
                  Acordes, treino de ouvido e metrônomo para praticar todos os dias.
                </p>
              </div>
            </Link>
            <Link
              to="/teoria"
              className="group rounded-2xl border border-border bg-card p-6 hover:border-primary/50 transition flex items-start gap-4"
            >
              <div className="w-10 h-10 rounded-xl bg-primary/15 text-primary flex items-center justify-center flex-shrink-0">
                <BookOpen className="w-5 h-5" />
              </div>
              <div>
                <h3 className="font-semibold mb-1 group-hover:text-primary transition">Teoria musical</h3>
                <p className="text-sm text-muted-foreground">
                  Anatomia do violão, harmonia e formação de acordes explicados de forma simples.
                </p>
              </div>
            </Link>
          </div>
        </div>
      </section>
    </SiteShell>
  );
}
