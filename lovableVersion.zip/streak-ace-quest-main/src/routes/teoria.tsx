import { createFileRoute } from "@tanstack/react-router";
import { BookOpen } from "lucide-react";
import { SiteShell } from "@/components/guitar/SiteShell";
import { TheorySidebar, THEORY_TOPICS } from "@/components/guitar/TheorySidebar";

const THEORY_CONTENT: Record<string, { title: string; body: string }> = {
  "violao-anatomia": {
    title: "Anatomia do violão",
    body:
      "O violão é dividido em corpo, braço e cabeça. O corpo amplifica o som das cordas; o braço contém as casas separadas pelos trastes, onde pressionamos as cordas; a cabeça abriga as tarraxas, usadas para afinar.",
  },
  "violao-cordas": {
    title: "As cordas e a afinação",
    body:
      "Da corda mais grave (6ª) para a mais aguda (1ª), a afinação padrão é Mi, Lá, Ré, Sol, Si, Mi. Cada corda solta produz uma nota, e ao pressionar uma casa nós encurtamos a corda, elevando a nota.",
  },
  "violao-som": {
    title: "Como o som é produzido",
    body:
      "Quando uma corda vibra, ela movimenta o ar dentro da caixa de ressonância. O tampo do violão amplifica essa vibração, gerando o som que ouvimos. A madeira e o formato influenciam diretamente no timbre.",
  },
  "harmonia-intervalos": {
    title: "Intervalos musicais",
    body:
      "Intervalo é a distância entre duas notas. Os intervalos básicos são: segunda, terça, quarta, quinta, sexta, sétima e oitava. Cada um pode ser maior, menor, justo, aumentado ou diminuto.",
  },
  "harmonia-escalas": {
    title: "Escalas maiores e menores",
    body:
      "A escala maior segue o padrão tom-tom-semitom-tom-tom-tom-semitom. A escala menor natural altera esse padrão e gera uma sonoridade mais melancólica. Saber as escalas é a base para improvisar e compor.",
  },
  "harmonia-tonalidade": {
    title: "Tonalidade e campo harmônico",
    body:
      "A tonalidade é o 'centro' de uma música. O campo harmônico mostra os acordes que naturalmente combinam dentro de uma tonalidade — por isso músicas em Dó maior costumam usar C, Dm, Em, F, G, Am.",
  },
  "acordes-triades": {
    title: "Tríades",
    body:
      "Uma tríade é um acorde com três notas: fundamental, terça e quinta. Tríades maiores têm terça maior; tríades menores têm terça menor. Quase todo acorde básico de violão é uma tríade.",
  },
  "acordes-cifras": {
    title: "Lendo cifras",
    body:
      "Cifras são letras que representam acordes: C = Dó maior, Cm = Dó menor, C7 = Dó com sétima. Aprender a ler cifras te abre o acesso à imensa biblioteca de músicas em sites como o Cifra Club.",
  },
  "acordes-inversoes": {
    title: "Inversões",
    body:
      "Uma inversão acontece quando a nota mais grave do acorde não é a fundamental. Inversões deixam as transições entre acordes mais suaves e geram baixos melódicos interessantes.",
  },
};

export const Route = createFileRoute("/teoria")({
  component: TeoriaPage,
  head: () => ({
    meta: [
      { title: "Teoria musical — StartGuitar" },
      {
        name: "description",
        content: "Conceitos essenciais de teoria musical aplicados ao violão: anatomia, harmonia e formação de acordes.",
      },
      { property: "og:title", content: "Teoria musical — StartGuitar" },
      {
        property: "og:description",
        content: "Entenda a música por trás do violão.",
      },
    ],
  }),
});

function TeoriaPage() {
  return (
    <SiteShell>
      <section className="pt-24 pb-20 sm:pt-32 sm:pb-24">
        <div className="max-w-6xl mx-auto px-5">
          <div className="mb-10">
            <p className="text-xs font-semibold uppercase tracking-widest text-primary mb-3">
              <BookOpen className="inline w-3.5 h-3.5 mr-1" /> Teoria musical
            </p>
            <h1 className="text-3xl sm:text-4xl font-bold tracking-tight">
              Entenda a música por trás do violão
            </h1>
          </div>

          <div className="grid lg:grid-cols-[1fr_240px] gap-10">
            <article className="space-y-10 max-w-2xl">
              {THEORY_TOPICS.map((t) => {
                const c = THEORY_CONTENT[t.id];
                return (
                  <div key={t.id} id={t.id} className="scroll-mt-24">
                    <p className="text-xs uppercase tracking-widest text-muted-foreground mb-2">{t.group}</p>
                    <h2 className="text-2xl font-semibold tracking-tight mb-3">{c.title}</h2>
                    <p className="text-base leading-relaxed text-muted-foreground">{c.body}</p>
                  </div>
                );
              })}
            </article>

            <aside className="hidden lg:block">
              <div className="sticky top-20">
                <TheorySidebar />
              </div>
            </aside>
          </div>
        </div>
      </section>
    </SiteShell>
  );
}