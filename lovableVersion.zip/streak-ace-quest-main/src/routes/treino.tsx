import { createFileRoute } from "@tanstack/react-router";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { ChordDiagram, COMMON_CHORDS } from "@/components/guitar/ChordDiagram";
import { EarTrainer } from "@/components/guitar/EarTrainer";
import { Metronome } from "@/components/guitar/Metronome";
import { SiteShell } from "@/components/guitar/SiteShell";

export const Route = createFileRoute("/treino")({
  component: TreinoPage,
  head: () => ({
    meta: [
      { title: "Treino — StartGuitar" },
      {
        name: "description",
        content: "Biblioteca de acordes, treino de ouvido musical e metrônomo para praticar violão todos os dias.",
      },
      { property: "og:title", content: "Treino — StartGuitar" },
      {
        property: "og:description",
        content: "Suas ferramentas de prática diária: acordes, ouvido e ritmo.",
      },
    ],
  }),
});

function TreinoPage() {
  return (
    <SiteShell>
      <section className="pt-24 pb-20 sm:pt-32 sm:pb-24">
        <div className="max-w-6xl mx-auto px-5">
          <div className="text-center mb-10">
            <p className="text-xs font-semibold uppercase tracking-widest text-primary mb-3">Prática e estudo</p>
            <h1 className="text-3xl sm:text-4xl font-bold tracking-tight">Suas ferramentas de treino</h1>
            <p className="mt-3 text-muted-foreground max-w-xl mx-auto">
              Acordes, ouvido e ritmo — tudo o que você precisa para praticar todos os dias.
            </p>
          </div>

          <Tabs defaultValue="acordes" className="w-full">
            <TabsList className="grid grid-cols-3 max-w-md mx-auto bg-muted/50 p-1 rounded-xl">
              <TabsTrigger value="acordes">Acordes</TabsTrigger>
              <TabsTrigger value="ouvido">Ouvido</TabsTrigger>
              <TabsTrigger value="metronomo">Metrônomo</TabsTrigger>
            </TabsList>

            <TabsContent value="acordes" className="mt-8">
              <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-4">
                {COMMON_CHORDS.map((c) => (
                  <div
                    key={c.name}
                    className="rounded-2xl border border-border bg-card p-4 flex items-center justify-center text-foreground hover:border-primary/50 transition"
                  >
                    <ChordDiagram chord={c} size={130} />
                  </div>
                ))}
              </div>
            </TabsContent>

            <TabsContent value="ouvido" className="mt-8">
              <EarTrainer />
            </TabsContent>

            <TabsContent value="metronomo" className="mt-8">
              <Metronome />
            </TabsContent>
          </Tabs>
        </div>
      </section>
    </SiteShell>
  );
}